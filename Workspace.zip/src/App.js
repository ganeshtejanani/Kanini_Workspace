import './App.css';
import { RouterPage } from './Components/RouterPage/RouterPage';

function App() {
  return (
    <div className='App'>
      <RouterPage/>
    </div>
  );
}

export default App;
