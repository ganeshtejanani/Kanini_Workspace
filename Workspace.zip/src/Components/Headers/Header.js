import React, { useState } from "react";
import './header.css'
import KaniniLogo from './images/KaniniLogo.png'
import NotificationAlert from './images/NotificationAlert.png'
import RoomImage from './images/Room.png'
import DownGreyArrow from './images/downarrow-grey.svg'
import DownBlackArrow from './images/downarrow-black.svg'
import DeskImage from './images/desk.png';
import Avatar from './images/avatar.png'
import { Home } from "../Home/Home";
import { Footer } from "../Footer/Footer";
import { Event } from "../Event/Event";
import { EventView } from "../EventView/EventView";
import { Room } from "../Room/Room";


export const Header=()=>
{
    const [selection,setSelection]=useState('Home');
    const [show,setShow]=useState(false);
    const [eventViewData,setEventViewData]=useState({})
    const [backEvent,setBackEvent]=useState('')
    const TriggerChangeSelection=(valueSelected)=>
    {
        setSelection(valueSelected);
    }
    return(
        <div className="landingpage-container">
    <div className="header-container">
        <div className="kanini-logo-header" onClick={()=>setSelection('Home')}>
            <img src={KaniniLogo} height='20'></img>
            <div>Kanini </div>
            <div> Workspace</div>
        </div>
        <div className="kanini-header-selection">
            <div className={selection==='Home'?"active-selection":''} onClick={()=>setSelection('Home')}>Home</div>
            <div className={['Room','Desks'].includes(selection)?"active-selection":''}><span>Book Space
                <img src={['Room','Desks'].includes(selection)?DownBlackArrow:DownGreyArrow} height={14}  onClick={()=>setShow(true)}></img></span>
                {show?<div className="bookspace-dropdown">
                    <div onClick={()=>{setSelection('Room');setShow(false);}}><img src={RoomImage} height='16'></img>Room</div>
                    <div onClick={()=>{setSelection('Desks');setShow(false);}}><img src={DeskImage} height='16'></img>Desks</div>
                </div>:''}
                </div>
            <div className={selection==='Bookings'?"active-selection":''} onClick={()=>setSelection('Bookings')}>Your bookings</div>
            <div className={selection==='Events'?"active-selection":''} onClick={()=>setSelection('Events')}>Events</div>
            <div className={selection==='Calender'?"active-selection":''} onClick={()=>setSelection('Calender')}>Calender</div>
        </div>
        <div className="kanini-header-name"><span><img src={NotificationAlert} height='20' className="notification-img"></img> <img src={Avatar} height='28' className="avatar-header"></img>
        Sriram Muniapan <img src={DownBlackArrow} height='14'></img></span></div>
    </div>
    <div className="landing-page-main-container">
        {selection==='Home'?<Home TriggerChangeSelection={TriggerChangeSelection} EventSet={setEventViewData} setBack={setBackEvent}/>:
        selection==='Events'?<Event TriggerChangeSelection={TriggerChangeSelection} EventSet={setEventViewData} setBack={setBackEvent}/>:
        selection==='EventView'?<EventView eventData={eventViewData} TriggerChangeSelection={TriggerChangeSelection} backEvent={backEvent}/>:
        selection==='Room'?<Room/>:""}
    </div>
    <div>
    <Footer/>
    </div>
    </div>)
}