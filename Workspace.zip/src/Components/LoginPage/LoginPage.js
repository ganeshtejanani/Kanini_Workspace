import React, { useEffect, useState } from "react";
import KaniniCanvasImage from './images/kaniniCanvasImage.jpg'
import CanvasText from './images/CanvasText.png'
import KaniniLogo from './images/kaniniLogo.png'
import {FormControl,Button,Modal} from 'react-bootstrap'
import ForgotPassImage from './images/forgotPass.png'
import CloseButtonImage from './images/closeButton.png'
import './loginpage.css'

export const LoginPage=()=>
{
    const [show,setShow]=useState(false);
    const [emailId,setEmailId]=useState('');
    const [password,setPassword]=useState('');
    const [forgotPassword,setForgotPassoword]=useState('');
    return (
        <>
        <Modal show={show} dialogClassName="forgot-modal" backdropClassName="forgot-backdrop">
            <Modal.Body>
                <div className="modal-close-button" onClick={()=>setShow(false)}><img src={CloseButtonImage} height='23'></img></div>
                <div className="forgot-image" ><img src={ForgotPassImage} height='65'></img></div>
                <div className="forgot-header">
                    <div>Forgot Password?</div>
                    <div>No worries, we'll send you reset instructions.</div>
                </div>
                <div className="login-form-container forgot-pass-form">
                <label>Email ID</label>
                <FormControl type="text" placeholder="name@kanini.com" value={forgotPassword} onChange={(e)=>setForgotPassoword(e.target.value)}></FormControl>
                <Button className={forgotPassword?"forgot-login-button":"forgot-login-button-active"}>SIGN IN</Button>
                </div>
            </Modal.Body>
        </Modal>
        <div className="login-container">
            <div className="login-canvas-image">
                <img src={KaniniCanvasImage} height='100%' width='100%'></img>
                <img src={CanvasText} className="canvastext" ></img>
            </div>
            <div className="login-container-box">
                <div className="login-box">
                    <img src={KaniniLogo} height='50px'></img>
                    <div className="login-header">
                    <div>Sign In</div>
                    <div>Welcome back! Please enter email id and password</div>
                    </div>
                    <div className="login-form-container">
                        <label>Email ID</label>
                        <FormControl type="text" placeholder="name@kanini.com" value={emailId} onChange={(e)=>setEmailId(e.target.value)}></FormControl>
                        <label>Passowrd</label>
                        <FormControl type="password" placeholder="**************" value={password} onChange={(e)=>setPassword(e.target.value)}></FormControl>
                    </div>
                    <div className="forgot-password" onClick={()=>setShow(true)}>Forgot your password?</div>
                    <Button className={emailId && password?"login-button-active":"login-button"}>SIGN IN</Button>
                </div>
            </div>
        </div>
        </>
    )
}