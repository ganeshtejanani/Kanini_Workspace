import {React} from "react";
import { Route, BrowserRouter, Routes} from 'react-router-dom';
import { LoginPage } from "../LoginPage/LoginPage";
import { Header } from "../Headers/Header";

export const RouterPage=()=>{
    return(<>
    <BrowserRouter>
    <Routes >
        <Route path='/' element={<LoginPage/>}></Route>
        <Route path='/landingpage' element={<Header/>}></Route>
    </Routes>
    </BrowserRouter>
    </>)
}