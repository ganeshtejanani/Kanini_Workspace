import React, { useState } from 'react'
import './room.css'
import Tv from './images/tv.png'
import EpBoard from './images/ep_board.png'
import MeetingRoom1 from './images/meeting-room1.png'
import MeetingRoom2 from './images/meeting-room2.png'
import EmployeeCount from './images/empolyee_count.png'
import LocationImage from './images/Location.png'
import CalenderImage from './images/calender.png'
import DownBlackArrow from './images/downarrow-black.svg'
export const Room=()=>
{
    const [showOffice,setShowOffice]=useState(true)
    return(<div className='room-container'>
        <div className='room-header'>Book a Room</div>
        <div className='room-sub-header'>Book a conference room at any kanini location</div>
        <div className='room-search-container'>
            <span><div><img src={LocationImage} height='18'></img> Ratha Tek,Chennai</div> 
            <img src={DownBlackArrow} height='20'></img>
            <div className='room-search-label'>Location</div>
            </span>
            {showOffice?
                    <div className="office-dropdown room-dropdown">
                    <div >Rattha Tek Meadows,Chennai</div>
                    <div >Rattha Tek Meadows,Chennai</div>
                    <div >Rattha Tek Meadows,Chennai</div>
                    <div >Rattha Tek Meadows,Chennai</div>
                   </div>
                    :''}
            <span><div><img src={CalenderImage} height='18'></img> 11/07/2022</div> 
            <img src={DownBlackArrow} height='20'></img>
            <div className='room-search-label'>Date</div>
            </span>
            <span><div><img src={EmployeeCount} height='18'></img> 8</div> 
            <img src={DownBlackArrow} height='20'></img>
            <div className='room-search-label'>Employees</div>
            </span>
            <div className='search-button-room'>Search</div>
        </div>
        <div>
        <div className="meeting-card">
                            <div className="meeting-card-image">
                            <img src={MeetingRoom1} width='100%' height='100%'></img>
                            </div>
                            <div className="meeting-card-content">
                                <div className="content-card-header">
                                    <div className="room-name-card">
                                        <div>Conference Room:</div>
                                        <div>Spring 4Pax</div>
                                    </div>
                                </div>
                                <div className='content-card-acc'>
                                    <span><img src={EmployeeCount} height='14'></img> 20</span>
                                    <span><img src={Tv} height='14'></img> TV</span>
                                    <span><img src={EpBoard} height='14'></img> Whiteboard</span>
                                </div>
                            </div>
                        </div>
        </div>
    </div>)
}